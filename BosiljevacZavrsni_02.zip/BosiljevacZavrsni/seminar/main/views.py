from django.shortcuts import render, redirect
from django.shortcuts import get_object_or_404
from django.views.generic import ListView
from main.models import Redatelj,Glumac,Studio,Osoblje,Reklama,Film,Serija
from django.contrib.auth.forms import UserCreationForm
from .forms import CreateUserForm
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required

@login_required(login_url='/ulogiravanje')
def homepage(request):
    return render(request, "base_generic.html")

def crud(request):

    if request.method == 'POST':
        film_ime = request.POST['film_ime']
        film_datum_objave = request.POST['film_datum_objave']
        film_zanr = request.POST['film_zanr']
        film_ocjena = request.POST['film_ocjena']
        film_budzet = request.POST['film_budzet']
        film_drzava_proizvodnje = request.POST['film_drzava_proizvodnje']

        # redatelj = request.POST['redatelj']
        # studio = request.POST['studio']
        # reklama = request.POST['reklama']
        # glumac = request.POST['glumac']
        # osoblje = request.POST['osoblje']

        new_movie = Film(film_ime=film_ime, film_datum_objave=film_datum_objave, film_zanr=film_zanr, film_ocjena=film_ocjena, film_budzet=film_budzet, film_drzava_proizvodnje=film_drzava_proizvodnje)
        new_movie.save()

    return render(request, "crud.html")

def crudserije(request):

    if request.method == 'POST':
        serija_ime = request.POST['serija_ime']
        serija_datum_objave = request.POST['serija_datum_objave']
        serija_zanr = request.POST['serija_zanr']
        serija_ocjena = request.POST['serija_ocjena']
        serija_budzet = request.POST['serija_budzet']
        serija_drzava_proizvodnje = request.POST['serija_drzava_proizvodnje']

        # redatelj = request.POST['redatelj']
        # studio = request.POST['studio']
        # reklama = request.POST['reklama']
        # glumac = request.POST['glumac']
        # osoblje = request.POST['osoblje']

        new_series = Serija(serija_ime=serija_ime, serija_datum_objave=serija_datum_objave, serija_zanr=serija_zanr, serija_ocjena=serija_ocjena, serija_budzet=serija_budzet, serija_drzava_proizvodnje=serija_drzava_proizvodnje)
        new_series.save()

    return render(request, "crud2.html")
    
def registracija(request):
    form = CreateUserForm()

    if request.method == 'POST':
        form = CreateUserForm(request.POST)
        if form.is_valid():
            form.save()
            user = form.cleaned_data.get('username')
            messages.success(request, 'Racun kreiran za ' + user)
            return redirect('/ulogiravanje')

    context = { 'form' : form }
    return render(request, "registracija.html", context)

def ulogiravanje(request):

    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        user = authenticate(request, username=username, password=password)

        if user is not None:
            login(request, user)
            return redirect('/')
        else:
            messages.info(request, 'Username ili lozinka netocni')

    context = {}
    return render(request, "ulogiravanje.html", context)


@login_required(login_url='/ulogiravanje')
def odlogiravanje(request):
    logout(request)
    return redirect('/ulogiravanje')

class moviesearch(ListView):
    model = Film
    template_name = 'moviesearch.html'
    
    def get_queryset(self):
        query = self.request.GET.get("q")
        object_list = Film.objects.filter(film_ime__icontains=query)
        return object_list
    

class seriessearch(ListView):
    model = Serija
    template_name = 'seriessearch.html'

    def get_queryset(self):
        query = self.request.GET.get("q")
        object_list = Serija.objects.filter(serija_ime__icontains=query)
        return object_list
    
def deletefilm(request, pk):
    film= Film.objects.get(pk=pk)
    film.delete()

    return redirect('/')

def deleteserija(request, pk):
    film= Serija.objects.get(pk=pk)
    film.delete()

    return redirect('/')

# def moviesearch(request):
#     movies = Film.objects.filter(film_ime__icontains='t')

#     context = {'movies' : movies }

#     return render(request, 'moviesearch.html', context=context)


# def deletefilm(request, pk):

#     b = Film.objects.get(pk=pk)
#     b.delete()

#     return redirect('/')


class RedateljList(ListView):
    model=Redatelj

class GlumacList(ListView):
    model=Glumac

class StudioList(ListView):
    model=Studio

class OsobljeList(ListView):
    model=Osoblje

class ReklamaList(ListView):
    model=Reklama

class FilmList(ListView):
    model=Film

class SerijaList(ListView):
    model=Serija