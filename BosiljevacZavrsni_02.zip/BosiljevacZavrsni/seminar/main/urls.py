from django.urls import path, include
from . import views
from main.views import RedateljList,GlumacList,StudioList,OsobljeList,ReklamaList,FilmList,SerijaList, moviesearch, seriessearch

app_name='main'

urlpatterns=[
    path('', views.homepage,name='homepage'),
    path('crud', views.crud, name='crud'),
    path('crud2', views.crudserije, name='crud2'),
    path('redatelj',RedateljList.as_view()),
    path('glumac',GlumacList.as_view()),
    path('studio',StudioList.as_view()),
    path('osoblje',OsobljeList.as_view()),
    path('reklama',ReklamaList.as_view()),
    path('film',FilmList.as_view()),
    path('serija',SerijaList.as_view()),
    path('moviesearch', moviesearch.as_view() , name='moviesearch'),
    path('seriessearch', seriessearch.as_view(), name='seriessearch'),
    path('registracija', views.registracija, name="registracija"),
    path('ulogiravanje', views.ulogiravanje, name="ulogiravanje"),
    path('odlogiravanje', views.odlogiravanje, name="odlogiravanje"),
    path('deletefilm/<pk>',views.deletefilm,name="deletefilm"),
    path('deleteserija/<pk>', views.deleteserija, name='deleteserija'),
]